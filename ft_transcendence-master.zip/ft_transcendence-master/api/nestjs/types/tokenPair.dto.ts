export class tokenPairDto
{
    access_token: string;
    refresh_token: string;
}