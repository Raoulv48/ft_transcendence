export class ReqRefreshTokens
{
    user: { sub: number, refreshToken: string, auth: boolean };
}