export class ReqExtractId
{
    user: { sub: number };
}