export enum ladder {
    NEW_PLAYER,
    IRON,
    BRONZE,
    SILVER,
    PLATINUM,
    DIAMOND,
}
