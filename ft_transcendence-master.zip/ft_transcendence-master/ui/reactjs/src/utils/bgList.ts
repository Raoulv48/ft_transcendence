const bgList: string = ['Default', 'David', 'Oscar', 'Nicolas'];

export default bgList;